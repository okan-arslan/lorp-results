LoRP infeasibility evidence

Each numbered folder matches the zero-padded index in instances.csv.
Open <index>/evidence.json with a JSON or text editor. summary.json gives
the counts and limitations for the whole archive.

There are 2,904 setting folders:
- 2,822 preserve a solver report declaring infeasibility. These are not
  independently replayed branch-tree proofs.
- 82 also contain a separately checked exhaustive integer certificate.
  Their original solver runs timed out without an incumbent; the separate
  certificate, not that timeout, establishes infeasibility.

The basis field distinguishes these groups. The original solver status and
report are retained. Each exhaustive certificate has nested witnesses,
which rule out all permitted facility choices; witnesses are not extra runs.

There is one evidence file per infeasible setting, not a 3h/5h report pair.
For solution indexing and solver-field explanations, see RESULTS.md.
